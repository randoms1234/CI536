function openSideBar(){
    document.getElementById("sidebar").style.width = "250px";
    document.getElementById("scrbtn").style.display = "none";
  }
  
  function closeSideBar(){
    document.getElementById("sidebar").style.width = "0";
    document.getElementById("scrbtn").style.display = "block";
  }
