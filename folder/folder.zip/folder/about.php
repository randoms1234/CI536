<?php
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="css/style.css" rel="stylesheet" type="text/css">
  <script src="js/index.js"></script>
    <title>About</title>
</head>
<header>
  <div class="topnav">
    <div class="active">
      <h3>MarketPlace</h3>
    </div>
    <div id="links">
      <a href="index.php">Home</a>
      <a href="buying.php">Buying</a>
      <a href="selling.php">Selling</a>
      <a href="account.php">Account</a>
      <a href="login.php">Login</a>
    </div>
    <a href="javascript:void(0);" class="icon" onclick="myFunction()">
      <i class="fa fa-bars"></i>
    </a>
  </div>
</header>
<body>
  <main>
    <div id="wrapper">
      <article class="home">
        <h2>Our website is specially tailored to university students to allow them to buy and sell new or second hand clothes and items.</h2>
      </article>
     
    </div>
  </main>
</body>
<footer></footer>
</html>